package com.example.mbm

import java.io.File

data class Journal(
    val id: String, // e.g., "0001"
    val name: String, // e.g., "Journal"
    val folder: File
) {
    fun getDisplayName(): String = name
    fun getFolderName(): String = "${id}_$name"
}