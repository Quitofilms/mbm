package com.example.mbm

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.slider.Slider

@OptIn(UnstableApi::class)
class TrimmerActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var timeSlider: Slider
    private lateinit var tvTimestamp: TextView
    private lateinit var btnConfirm: Button
    private lateinit var btnPreview: Button

    private var videoUri: Uri? = null
    private var videoDurationMs: Long = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trimmer)

        playerView = findViewById(R.id.player_view)
        timeSlider = findViewById(R.id.time_slider)
        tvTimestamp = findViewById(R.id.tv_timestamp)
        btnConfirm = findViewById(R.id.btn_confirm_trim)
        btnPreview = findViewById(R.id.btn_preview_moment)

        videoUri = intent.getParcelableExtra("VIDEO_URI")

        setupPlayer()

        timeSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                // FORCE PAUSE: This ensures the video never autoplays while you are sliding the ball
                player.pause()
                player.seekTo(value.toLong())
                updateTimestampText(value.toLong())
            }
        }

        btnPreview.setOnClickListener {
            val startMs = timeSlider.value.toLong()
            player.seekTo(startMs)
            player.play()

            // Play for exactly one second then automatically pause and return to seeker position
            handler.postDelayed({
                player.pause()
                player.seekTo(startMs)
            }, 1000)
        }

        btnConfirm.setOnClickListener {
            val startMs = timeSlider.value.toLong()
            val resultIntent = Intent()
            resultIntent.putExtra("START_MS", startMs)
            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }

    private fun setupPlayer() {
        player = ExoPlayer.Builder(this).build()
        playerView.player = player

        videoUri?.let {
            val mediaItem = MediaItem.fromUri(it)
            player.setMediaItem(mediaItem)
            player.prepare()
            // INITIAL STATE: Player starts in a paused state
            player.playWhenReady = false
        }

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    videoDurationMs = player.duration
                    // Ensure the seeker cannot be set within the last second of the video
                    val maxStart = if (videoDurationMs > 1000) videoDurationMs - 1000 else 0
                    timeSlider.valueFrom = 0f
                    timeSlider.valueTo = maxStart.toFloat()

                    if (timeSlider.value > maxStart) {
                        timeSlider.value = 0f
                    }
                    updateTimestampText(timeSlider.value.toLong())
                }
            }
        })
    }

    private fun updateTimestampText(currentMs: Long) {
        val seconds = currentMs / 1000
        val millis = (currentMs % 1000) / 100
        tvTimestamp.text = String.format("Start at: %02d.%d seconds", seconds, millis)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        player.release()
    }
}