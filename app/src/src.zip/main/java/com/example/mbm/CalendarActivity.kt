package com.example.mbm

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.Calendar
import java.util.Locale

class CalendarActivity : AppCompatActivity() {

    private lateinit var tvMonthYear: TextView
    private lateinit var rvCalendar: RecyclerView
    private lateinit var journalId: String
    private lateinit var journalPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)

        journalId = intent.getStringExtra("JOURNAL_ID") ?: "0001"
        journalPath = intent.getStringExtra("JOURNAL_PATH") ?: ""

        tvMonthYear = findViewById(R.id.tv_month_year)
        rvCalendar = findViewById(R.id.rv_calendar_grid)

        val calendar = Calendar.getInstance()
        val monthName = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())
        val year = calendar.get(Calendar.YEAR)
        tvMonthYear.text = "${monthName?.uppercase()} $year"

        setupCalendarGrid()
    }

    private fun setupCalendarGrid() {
        val daysInMonth = 31
        val directory = File(journalPath)

        // Ensure the directory exists to prevent crashes
        if (!directory.exists()) {
            directory.mkdirs()
        }

        rvCalendar.layoutManager = GridLayoutManager(this, 3)
        // Actual adapter initialization would happen here based on your project structure
    }
}