package com.example.mbm

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.InputFilter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var fabAddJournal: FloatingActionButton
    private lateinit var tvDashboardPath: TextView
    private val STORAGE_PERMISSION_CODE = 101
    private val journals = mutableListOf<Journal>()
    private lateinit var adapter: JournalAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        recyclerView = findViewById(R.id.rv_journals_grid)
        fabAddJournal = findViewById(R.id.fab_add_journal)
        tvDashboardPath = findViewById(R.id.tv_dashboard_path)

        setupDashboard()

        fabAddJournal.setOnClickListener {
            checkPermissionsAndAction { showCreateJournalDialog() }
        }
    }

    override fun onResume() {
        super.onResume()
        setupDashboard()
    }

    private fun setupDashboard() {
        val root = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "MBM")
        if (!root.exists()) {
            root.mkdirs()
        }

        loadJournalsFromStorage(root)

        // Sets the path text to show the EXACT subfolder of the first journal (e.g., MBM/0001)
        if (journals.isNotEmpty()) {
            tvDashboardPath.text = journals[0].folder.absolutePath
        } else {
            tvDashboardPath.text = root.absolutePath
        }

        adapter = JournalAdapter(journals) { selectedJournal ->
            val intent = Intent(this, CalendarActivity::class.java)
            intent.putExtra("JOURNAL_ID", selectedJournal.id)
            intent.putExtra("JOURNAL_NAME", selectedJournal.name)
            intent.putExtra("JOURNAL_PATH", selectedJournal.folder.absolutePath)
            startActivity(intent)
        }

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        recyclerView.adapter = adapter
    }

    private fun loadJournalsFromStorage(root: File) {
        journals.clear()

        val firstFolder = File(root, "0001")
        if (!firstFolder.exists()) {
            firstFolder.mkdirs()
        }

        val directories = root.listFiles { file -> file.isDirectory && file.name.length == 4 }

        directories?.sortedBy { it.name }?.forEach { folder ->
            val idStr = folder.name
            val nameStr = "JOURNAL"
            journals.add(Journal(idStr, nameStr, folder))
        }

        if (journals.isEmpty()) {
            journals.add(Journal("0001", "JOURNAL", firstFolder))
        }
    }

    private fun showCreateJournalDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Name your Journal")
        val input = EditText(this)
        input.filters = arrayOf(InputFilter.LengthFilter(10))
        input.hint = "Max 10 chars"
        builder.setView(input)
        builder.setPositiveButton("Create") { _, _ ->
            val name = input.text.toString().ifEmpty { "New" }
            createNewJournal(name)
        }
        builder.setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
        builder.show()
    }

    private fun createNewJournal(name: String) {
        val root = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "MBM")
        val nextId = String.format("%04d", journals.size + 1)
        val newFolder = File(root, nextId)
        if (!newFolder.exists()) {
            newFolder.mkdirs()
        }
        journals.add(Journal(nextId, name, newFolder))
        adapter.notifyDataSetChanged()
    }

    private fun checkPermissionsAndAction(action: () -> Unit) {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val allGranted = perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (allGranted) action() else ActivityCompat.requestPermissions(this, perms, STORAGE_PERMISSION_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            setupDashboard()
        }
    }

    inner class JournalAdapter(private val items: List<Journal>, private val onClick: (Journal) -> Unit) : RecyclerView.Adapter<JournalAdapter.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val ivThumbnail: ImageView = view.findViewById(R.id.iv_journal_thumbnail)
            val tvId: TextView = view.findViewById(R.id.tv_journal_id)
            val tvName: TextView = view.findViewById(R.id.tv_journal_name)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_journal_card, parent, false))
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.tvId.text = item.id
            holder.tvName.text = item.name.uppercase()
            val lastFile = item.folder.listFiles { f -> !f.isDirectory }?.maxByOrNull { it.lastModified() }
            if (lastFile != null) {
                Glide.with(holder.itemView.context).asBitmap().load(lastFile).apply(RequestOptions().frame(1000000).centerCrop()).diskCacheStrategy(DiskCacheStrategy.RESOURCE).into(holder.ivThumbnail)
            } else {
                holder.ivThumbnail.setImageResource(android.R.drawable.ic_menu_gallery)
            }
            holder.itemView.setOnClickListener { onClick(item) }
        }
        override fun getItemCount() = items.size
    }
}