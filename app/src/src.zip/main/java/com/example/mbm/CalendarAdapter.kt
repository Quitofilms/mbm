package com.example.mbm

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class CalendarAdapter(
    private val items: List<Any>,
    private val vaultPath: File,
    private val onDayClick: (Date) -> Unit,
    private val onDayLongClick: (Date) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_DAY = 1
    }

    private val selectedDates = mutableSetOf<Long>()
    private val fileDateFormatter = SimpleDateFormat("ddMMyyyy", Locale.getDefault())

    override fun getItemViewType(position: Int): Int {
        return if (items[position] is String) TYPE_HEADER else TYPE_DAY
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_month_header, parent, false)
            HeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_calendar_day, parent, false)
            DayViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is HeaderViewHolder) {
            holder.tvHeader.text = items[position] as String
        } else if (holder is DayViewHolder) {
            val date = items[position] as Date
            val calendar = Calendar.getInstance()
            calendar.time = date

            holder.tvDayNum.text = calendar.get(Calendar.DAY_OF_MONTH).toString()

            val dateStr = fileDateFormatter.format(date)
            val videoFile = File(vaultPath, "MBM_$dateStr.mp4")
            val imageFile = File(vaultPath, "MBM_$dateStr.jpg")

            holder.selectionOverlay.visibility = if (selectedDates.contains(date.time)) View.VISIBLE else View.GONE

            // Logic to ensure empty tiles are black by hiding the ImageView
            if (videoFile.exists()) {
                holder.ivThumbnail.visibility = View.VISIBLE
                holder.ivTypeIcon.visibility = View.VISIBLE
                holder.ivTypeIcon.setImageResource(android.R.drawable.ic_media_play)
                Glide.with(holder.itemView.context).load(videoFile).centerCrop().into(holder.ivThumbnail)
            } else if (imageFile.exists()) {
                holder.ivThumbnail.visibility = View.VISIBLE
                holder.ivTypeIcon.visibility = View.GONE
                Glide.with(holder.itemView.context).load(imageFile).centerCrop().into(holder.ivThumbnail)
            } else {
                holder.ivThumbnail.visibility = View.GONE
                holder.ivTypeIcon.visibility = View.GONE
            }

            holder.itemView.setOnClickListener { onDayClick(date) }
            holder.itemView.setOnLongClickListener {
                onDayLongClick(date)
                true
            }
        }
    }

    override fun getItemCount(): Int = items.size

    fun toggleSelection(date: Date) {
        if (selectedDates.contains(date.time)) {
            selectedDates.remove(date.time)
        } else {
            selectedDates.add(date.time)
        }
        notifyDataSetChanged()
    }

    fun clearSelection() {
        selectedDates.clear()
        notifyDataSetChanged()
    }

    fun getSelectedCount(): Int = selectedDates.size

    fun getSelectedDates(): List<Date> {
        return selectedDates.map { Date(it) }
    }

    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvHeader: TextView = view.findViewById(R.id.tv_month_header_text)
    }

    class DayViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivThumbnail: ImageView = view.findViewById(R.id.iv_day_thumbnail)
        val tvDayNum: TextView = view.findViewById(R.id.tv_day_number)
        val ivTypeIcon: ImageView = view.findViewById(R.id.iv_type_icon)
        val selectionOverlay: View = view.findViewById(R.id.selection_overlay)
    }
}